import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Card } from './components/ui/card';
import FeedbackForm from './components/FeedbackForm';
import CustomerTickets from './components/CustomerTickets';
import AdminDashboard from './components/AdminDashboard';
import { MessageSquare, Ticket, ShieldCheck } from 'lucide-react';

export default function App() {
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const handleTicketSubmit = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  const handleStatusUpdate = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <div className="mb-8 text-center">
          <h1 className="mb-2 text-blue-600">Customer Feedback & Support</h1>
          <p className="text-gray-600">Submit feedback, track tickets, and manage support requests</p>
        </div>

        <Tabs defaultValue="submit" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="submit" className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              Submit Feedback
            </TabsTrigger>
            <TabsTrigger value="tickets" className="flex items-center gap-2">
              <Ticket className="w-4 h-4" />
              My Tickets
            </TabsTrigger>
            <TabsTrigger value="admin" className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4" />
              Admin Dashboard
            </TabsTrigger>
          </TabsList>

          <TabsContent value="submit">
            <Card className="p-6">
              <FeedbackForm onTicketSubmit={handleTicketSubmit} />
            </Card>
          </TabsContent>

          <TabsContent value="tickets">
            <CustomerTickets key={refreshTrigger} />
          </TabsContent>

          <TabsContent value="admin">
            <AdminDashboard 
              key={refreshTrigger} 
              onStatusUpdate={handleStatusUpdate}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
