import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription } from './ui/alert';
import { Upload, CheckCircle2 } from 'lucide-react';

interface FeedbackFormProps {
  onTicketSubmit: () => void;
}

interface Ticket {
  id: string;
  customerName: string;
  customerEmail: string;
  issueType: string;
  description: string;
  fileName: string;
  status: 'Open' | 'In Progress' | 'Closed';
  createdAt: string;
}

export default function FeedbackForm({ onTicketSubmit }: FeedbackFormProps) {
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [issueType, setIssueType] = useState('');
  const [description, setDescription] = useState('');
  const [fileName, setFileName] = useState('');
  const [submittedTicketId, setSubmittedTicketId] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);

  const generateTicketId = (): string => {
    const timestamp = Date.now().toString(36);
    const randomStr = Math.random().toString(36).substring(2, 7).toUpperCase();
    return `TKT-${timestamp}-${randomStr}`;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const ticketId = generateTicketId();
    const ticket: Ticket = {
      id: ticketId,
      customerName,
      customerEmail,
      issueType,
      description,
      fileName,
      status: 'Open',
      createdAt: new Date().toISOString(),
    };

    // Get existing tickets from localStorage
    const existingTickets = JSON.parse(localStorage.getItem('supportTickets') || '[]');
    existingTickets.push(ticket);
    localStorage.setItem('supportTickets', JSON.stringify(existingTickets));

    // Show success message
    setSubmittedTicketId(ticketId);
    setShowSuccess(true);
    
    // Reset form
    setCustomerName('');
    setCustomerEmail('');
    setIssueType('');
    setDescription('');
    setFileName('');
    
    // Trigger refresh in parent
    onTicketSubmit();

    // Hide success message after 5 seconds
    setTimeout(() => {
      setShowSuccess(false);
    }, 5000);
  };

  return (
    <div>
      <div className="mb-6">
        <h2 className="mb-2">Submit Support Ticket</h2>
        <p className="text-gray-600">
          Having an issue? Fill out the form below and we'll get back to you as soon as possible.
        </p>
      </div>

      {showSuccess && (
        <Alert className="mb-6 bg-green-50 border-green-200">
          <CheckCircle2 className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            Ticket submitted successfully! Your ticket ID is: <span className="font-semibold">{submittedTicketId}</span>
          </AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="customerName">Name *</Label>
            <Input
              id="customerName"
              type="text"
              placeholder="Enter your name"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="customerEmail">Email *</Label>
            <Input
              id="customerEmail"
              type="email"
              placeholder="your.email@example.com"
              value={customerEmail}
              onChange={(e) => setCustomerEmail(e.target.value)}
              required
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="issueType">Type of Issue *</Label>
          <Select value={issueType} onValueChange={setIssueType} required>
            <SelectTrigger id="issueType">
              <SelectValue placeholder="Select issue type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="delay">Shipment Delay</SelectItem>
              <SelectItem value="missing">Missing Shipment</SelectItem>
              <SelectItem value="damaged">Damaged Package</SelectItem>
              <SelectItem value="tracking">Tracking Issue</SelectItem>
              <SelectItem value="billing">Billing Question</SelectItem>
              <SelectItem value="general">General Inquiry</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description *</Label>
          <Textarea
            id="description"
            placeholder="Please describe your issue in detail..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
            rows={6}
            className="resize-none"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="fileUpload">Attach File (Optional)</Label>
          <div className="flex items-center gap-4">
            <Button
              type="button"
              variant="outline"
              className="relative cursor-pointer"
              onClick={() => document.getElementById('fileUpload')?.click()}
            >
              <Upload className="w-4 h-4 mr-2" />
              Choose File
            </Button>
            <span className="text-gray-600">
              {fileName || 'No file chosen'}
            </span>
          </div>
          <Input
            id="fileUpload"
            type="file"
            onChange={handleFileChange}
            className="hidden"
            accept="image/*,.pdf,.doc,.docx"
          />
          <p className="text-gray-500 text-sm">Accepted formats: Images, PDF, DOC (Max 10MB)</p>
        </div>

        <Button type="submit" className="w-full md:w-auto px-8">
          Submit Ticket
        </Button>
      </form>
    </div>
  );
}
