import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Clock, FileText, Paperclip, Search } from 'lucide-react';

interface Ticket {
  id: string;
  customerName: string;
  customerEmail: string;
  issueType: string;
  description: string;
  fileName: string;
  status: 'Open' | 'In Progress' | 'Closed';
  createdAt: string;
}

export default function CustomerTickets() {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const storedTickets = JSON.parse(localStorage.getItem('supportTickets') || '[]');
    setTickets(storedTickets);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Open':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'In Progress':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Closed':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getIssueTypeLabel = (type: string) => {
    const labels: { [key: string]: string } = {
      delay: 'Shipment Delay',
      missing: 'Missing Shipment',
      damaged: 'Damaged Package',
      tracking: 'Tracking Issue',
      billing: 'Billing Question',
      general: 'General Inquiry',
      other: 'Other',
    };
    return labels[type] || type;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const filteredTickets = tickets.filter(ticket =>
    ticket.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    ticket.issueType.toLowerCase().includes(searchQuery.toLowerCase()) ||
    ticket.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div>
      <div className="mb-6">
        <h2 className="mb-2">My Support Tickets</h2>
        <p className="text-gray-600 mb-4">
          Track the status of your submitted support tickets
        </p>
        
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            type="text"
            placeholder="Search tickets by ID or keyword..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {filteredTickets.length === 0 ? (
        <Card className="p-12 text-center">
          <div className="flex flex-col items-center gap-3">
            <FileText className="w-12 h-12 text-gray-300" />
            <h3 className="text-gray-600">No tickets found</h3>
            <p className="text-gray-500">
              {searchQuery ? 'Try a different search term' : 'Submit a ticket to get started'}
            </p>
          </div>
        </Card>
      ) : (
        <div className="grid gap-4">
          {filteredTickets.map((ticket) => (
            <Card key={ticket.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <CardTitle className="text-blue-600">{ticket.id}</CardTitle>
                    <Badge className={getStatusColor(ticket.status)}>
                      {ticket.status}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-gray-500">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">{formatDate(ticket.createdAt)}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-gray-500 text-sm mb-1">Customer</p>
                      <p>{ticket.customerName}</p>
                      <p className="text-gray-600 text-sm">{ticket.customerEmail}</p>
                    </div>
                    <div>
                      <p className="text-gray-500 text-sm mb-1">Issue Type</p>
                      <p>{getIssueTypeLabel(ticket.issueType)}</p>
                    </div>
                  </div>
                  
                  <div>
                    <p className="text-gray-500 text-sm mb-1">Description</p>
                    <p className="text-gray-700">{ticket.description}</p>
                  </div>

                  {ticket.fileName && (
                    <div className="flex items-center gap-2 text-gray-600 pt-2">
                      <Paperclip className="w-4 h-4" />
                      <span className="text-sm">{ticket.fileName}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
