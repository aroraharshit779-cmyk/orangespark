import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Clock, FileText, Paperclip, TrendingUp } from 'lucide-react';

interface Ticket {
  id: string;
  customerName: string;
  customerEmail: string;
  issueType: string;
  description: string;
  fileName: string;
  status: 'Open' | 'In Progress' | 'Closed';
  createdAt: string;
}

interface AdminDashboardProps {
  onStatusUpdate: () => void;
}

export default function AdminDashboard({ onStatusUpdate }: AdminDashboardProps) {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  useEffect(() => {
    loadTickets();
  }, []);

  const loadTickets = () => {
    const storedTickets = JSON.parse(localStorage.getItem('supportTickets') || '[]');
    setTickets(storedTickets);
  };

  const updateTicketStatus = (ticketId: string, newStatus: 'Open' | 'In Progress' | 'Closed') => {
    const updatedTickets = tickets.map(ticket =>
      ticket.id === ticketId ? { ...ticket, status: newStatus } : ticket
    );
    setTickets(updatedTickets);
    localStorage.setItem('supportTickets', JSON.stringify(updatedTickets));
    onStatusUpdate();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Open':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'In Progress':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Closed':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getIssueTypeLabel = (type: string) => {
    const labels: { [key: string]: string } = {
      delay: 'Shipment Delay',
      missing: 'Missing Shipment',
      damaged: 'Damaged Package',
      tracking: 'Tracking Issue',
      billing: 'Billing Question',
      general: 'General Inquiry',
      other: 'Other',
    };
    return labels[type] || type;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getTicketsByStatus = (status: string) => {
    if (status === 'all') return tickets;
    return tickets.filter(ticket => ticket.status === status);
  };

  const openTickets = tickets.filter(t => t.status === 'Open').length;
  const inProgressTickets = tickets.filter(t => t.status === 'In Progress').length;
  const closedTickets = tickets.filter(t => t.status === 'Closed').length;

  const displayedTickets = getTicketsByStatus(filterStatus);

  return (
    <div>
      <div className="mb-6">
        <h2 className="mb-2">Admin Dashboard</h2>
        <p className="text-gray-600 mb-6">
          Manage and update support ticket statuses
        </p>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm mb-1">Total Tickets</p>
                  <p className="text-2xl">{tickets.length}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm mb-1">Open</p>
                  <p className="text-2xl text-blue-600">{openTickets}</p>
                </div>
                <div className="w-3 h-3 rounded-full bg-blue-500"></div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm mb-1">In Progress</p>
                  <p className="text-2xl text-yellow-600">{inProgressTickets}</p>
                </div>
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm mb-1">Closed</p>
                  <p className="text-2xl text-green-600">{closedTickets}</p>
                </div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Filters */}
      <Tabs value={filterStatus} onValueChange={setFilterStatus} className="mb-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">
            All ({tickets.length})
          </TabsTrigger>
          <TabsTrigger value="Open">
            Open ({openTickets})
          </TabsTrigger>
          <TabsTrigger value="In Progress">
            In Progress ({inProgressTickets})
          </TabsTrigger>
          <TabsTrigger value="Closed">
            Closed ({closedTickets})
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Tickets List */}
      {displayedTickets.length === 0 ? (
        <Card className="p-12 text-center">
          <div className="flex flex-col items-center gap-3">
            <FileText className="w-12 h-12 text-gray-300" />
            <h3 className="text-gray-600">No tickets in this category</h3>
          </div>
        </Card>
      ) : (
        <div className="grid gap-4">
          {displayedTickets.map((ticket) => (
            <Card key={ticket.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <CardTitle className="text-blue-600">{ticket.id}</CardTitle>
                    <Badge className={getStatusColor(ticket.status)}>
                      {ticket.status}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-gray-500">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">{formatDate(ticket.createdAt)}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-gray-500 text-sm mb-1">Customer</p>
                      <p>{ticket.customerName}</p>
                      <p className="text-gray-600 text-sm">{ticket.customerEmail}</p>
                    </div>
                    <div>
                      <p className="text-gray-500 text-sm mb-1">Issue Type</p>
                      <p>{getIssueTypeLabel(ticket.issueType)}</p>
                    </div>
                  </div>
                  
                  <div>
                    <p className="text-gray-500 text-sm mb-1">Description</p>
                    <p className="text-gray-700">{ticket.description}</p>
                  </div>

                  {ticket.fileName && (
                    <div className="flex items-center gap-2 text-gray-600">
                      <Paperclip className="w-4 h-4" />
                      <span className="text-sm">{ticket.fileName}</span>
                    </div>
                  )}

                  <div className="pt-4 border-t flex flex-col sm:flex-row gap-3">
                    <div className="flex-1">
                      <p className="text-gray-500 text-sm mb-2">Update Status</p>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant={ticket.status === 'Open' ? 'default' : 'outline'}
                          onClick={() => updateTicketStatus(ticket.id, 'Open')}
                          className="flex-1"
                        >
                          Open
                        </Button>
                        <Button
                          size="sm"
                          variant={ticket.status === 'In Progress' ? 'default' : 'outline'}
                          onClick={() => updateTicketStatus(ticket.id, 'In Progress')}
                          className="flex-1"
                        >
                          In Progress
                        </Button>
                        <Button
                          size="sm"
                          variant={ticket.status === 'Closed' ? 'default' : 'outline'}
                          onClick={() => updateTicketStatus(ticket.id, 'Closed')}
                          className="flex-1"
                        >
                          Closed
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
