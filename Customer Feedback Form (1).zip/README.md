
  # Customer Feedback Form

  This is a code bundle for Customer Feedback Form. The original project is available at https://www.figma.com/design/MdlRRdQpy13RliCvO00poU/Customer-Feedback-Form.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  